package cs201.project.afinal.thetraveler.model;

import java.util.Date;

/**
 * Created by simon on 11/13/2017.
 */

public class Post {

    //url to image
    private String mImageURL;

    //name of person
    private String mUsername;

    // name of location
    private String mLocation;

    //resource id of user picture
    private int mUserProfilePicture;

    //date of post
    private Date mDate;

    public Post() {

    }

    public Post(String imageURL, String username, String location, int userProfilePicture, Date date) {
        mImageURL = imageURL;
        mUsername = username;
        mLocation = location;
        mUserProfilePicture = userProfilePicture;
        mDate = date;
    }

    public String getImageURL() {
        return mImageURL;
    }

    public void setImageURL(String imageURL) {
        mImageURL = imageURL;
    }

    public String getUsername() {
        return mUsername;
    }

    public void setUsername(String username) {
        mUsername = username;
    }

    public String getLocation() {
        return mLocation;
    }

    public void setLocation(String location) {
        mLocation = location;
    }

    public int getUserProfilePicture() {
        return mUserProfilePicture;
    }

    public void setUserProfilePicture(int userProfilePicture) {
        mUserProfilePicture = userProfilePicture;
    }

    public Date getDate() {
        return mDate;
    }

    public void setDate(Date date) {
        mDate = date;
    }
}
